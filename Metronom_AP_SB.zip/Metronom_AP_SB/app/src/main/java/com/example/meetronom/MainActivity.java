package com.example.meetronom;

import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.content.Intent;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Handler handler;
    private boolean isRunning = false;
    private int tempo = 110;

    private SoundPool soundPool;
    private int metronomeSoundId;

    private int selectedMeter = 4;
    Button tkt_1, tkt_2, tkt_3;

    ActivityResultLauncher<Intent> launcher;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        handler = new Handler();

        initializeSoundPool();

        SeekBar tempoSeekBar = findViewById(R.id.Seeker);
        final TextView tempoTextView = findViewById(R.id.TV_1);
        Button startButton = findViewById(R.id.bSTART);
        Button stopButton = findViewById(R.id.bSTOP);

        tempoSeekBar.setProgress(tempo - 60); // Adjust for SeekBar range
        tempoTextView.setText("Tempo: " + tempo + " BPM");

        tempoSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                  tempo = progress + 60; // Adjust for SeekBar range
                tempoTextView.setText("Tempo: " + tempo + " BPM");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });


        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startMetronome();
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopMetronome();
            }
        });
    }

    private void initializeSoundPool() {
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_GAME)
                .build();

        soundPool = new SoundPool.Builder()
                .setMaxStreams(1)
                .setAudioAttributes(audioAttributes)
                .build();

        metronomeSoundId = soundPool.load(this, R.raw.metronome_sound, 1);
    }

    private void startMetronome() {
        if (!isRunning) {
            isRunning = true;
            playMetronomeTick();
        }
    }

    private void stopMetronome() {
        isRunning = false;
        handler.removeCallbacksAndMessages(null);
    }

    private void playMetronomeTick() {
        if (isRunning) {
            soundPool.play(metronomeSoundId, 2.0f, 2.0f, 1, 0, 2.0f);
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    playMetronomeTick();
                }
            }, 60000 / tempo);
        }
    }

    private long calculateTickDuration() {
        int beatsPerMinute = tempo ;
        return 60000 / beatsPerMinute;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        soundPool.release();
        soundPool = null;
    }

        @Override
                public void onClick(View view) {
            Intent intent = new Intent(MainActivity.this, tkt1.class);
            launcher.launch(intent);
        }
        ))
    }

}